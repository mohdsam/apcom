<?php
//Constants to connect with the database
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '123456');
define('DB_HOST', 'localhost');
define('DB_NAME', 'dawood_app');