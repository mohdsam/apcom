<?php

class DbOperation
{
    //Database connection link
    private $con;

    //Class constructor
    function __construct()
    {
        //Getting the DbConnect.php file
        require_once dirname(__FILE__) . '/DbConnect.php';

        //Creating a DbConnect object to connect to the database
        $db = new DbConnect();

        //Initializing our connection link of this class
        //by calling the method connect of DbConnect class
        $this->con = $db->connect();
    }

    public function get_all_device($to,$from){
        $res = $this->con->query("SELECT * FROM users WHERE role='2' LIMIT $to,$from");
        if($res->num_rows>0){
            $temp = array();
            while($row = $res->fetch_assoc()){
                array_push($temp,$row);
            }
            return $temp;
        }
        $this->con->close();
    }

    /*
     * Methods to check a user is valid or not using api key
     * I will not write comments to every method as the same thing is done in each method
     * */
    public function isValidAdmin($api_key) {
        //Creating an statement
        $stmt = $this->con->prepare("SELECT id from users WHERE  device_id = ? AND role = ?");
        
        //Binding parameters to statement with this
        //the question mark of queries will be replaced with the actual values
        $role =1;
        $stmt->bind_param("si", $api_key,$role);
        // $stmt->bind_param("i",1);


        //Executing the statement
        $stmt->execute();
        // echo $stmt->fullQuery;

        //Storing the results
        $stmt->store_result();

        //Getting the rows from the database
        //As API Key is always unique so we will get either a row or no row
        $num_rows = $stmt->num_rows;

        //Closing the statment
        $stmt->close();

        //If the fetched row is greater than 0 returning  true means user is valid
        return $num_rows > 0;
    }

    public function isValidUser($api_key){
        $res = $this->con->query("SELECT id FROM users WHERE device_id='$api_key' AND role='2' AND status='1'");
        if($res->num_rows>0){
            return $res->num_rows;
        }
    }

    public function add_trip($type,$status,$geo_cordinates) {
        $headers = apache_request_headers();
        $device_id = $headers['device_id'];
        if(!empty($type) && !empty($status)) {
            $cordinates = array();
            $get_cordinates = array_push($cordinates, mysqli_real_escape_string($geo_cordinates));
            json_encode($get_cordinates);
            echo json_encode($get_cordinates);
            // $res = $this->con->query("INSERT INTO trip (u_id,geo_cordinates,status,created_on) VALUES('$device_id','$get_cordinates','$status',NOW())");
            // if(!empty($res)){
            //     return $res;
            // }
        }
    }



    //This method will generate a unique api key
    private function generateApiKey(){
        return md5(uniqid(rand(), true));
    }
}